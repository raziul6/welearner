<?php
    /*
    Plugin Name: Welearn Plugin
    Plugin URI:
    Description: After install the welearn WordPress Theme, you must need to install this "welearn-plugin" first to get all functions of Welearn WP Theme.
    Author: WeDevs
    Author URI:
    Version: 1.0
    Text Domain: welearn-plugin
    Domain Path: /languages/
     */

    define( "WELEARNDIR", dirname( __FILE__ ) );
    define( "WELEARNDIRURL", plugin_dir_url( __FILE__ ) );
    define( "WELEARNDIRPATH", plugin_dir_path( __FILE__ ) );
    class WelearnPlugin {
        public function __construct() {
            add_action( 'plugins_loaded', array( $this, 'weln_load_textdomain' ) );
            add_action( 'init', array( $this, 'weln_courses_cpt' ) );
            add_action( 'init', array( $this, 'weln_team_cpt' ) );
            add_action( 'init', array( $this, 'weln_testimonial_cpt' ) );
            add_action( 'init', array( $this, 'weln_courses_topic_taxonomy' ) );
            add_action( 'admin_menu', array( $this, 'weln_courses_metabox' ) );
            add_action( 'save_post', array( $this, 'weln_save_price' ) );
            add_action( 'save_post', array( $this, 'weln_save_team_info' ) );
            add_action( 'save_post', array( $this, 'weln_save_testimonial_info' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'weln_styles_load' ) );
            add_action( 'init', array( $this, 'course_topic_color_opt' ) );
            add_action( 'category_add_form_fields', array( $this, 'course_topic_form_field' ) );
            add_action( 'course_topic_add_form_fields', array( $this, 'course_topic_form_field' ) );
            add_action( 'category_edit_form_fields', array( $this, 'course_topic_edit_form_field' ) );
            add_action( 'course_topic_edit_form_fields', array( $this, 'course_topic_edit_form_field' ) );
            add_action( 'create_category', array( $this, 'save_color_info_category' ) );
            add_action( 'create_course_topic', array( $this, 'save_color_info_category' ) );
            add_action( 'edit_course_topic', array( $this, 'edit_color_info_category' ) );
        }
        

            /**
             * Load Admin Style
             *
             * @return void
             */
            function weln_styles_load() {
                wp_enqueue_style( 'weln-admin-style', WELEARNDIRURL . '/assets/admin/css/style.css', null, time() );                     
            }

        function edit_color_info_category( $term_id ) {
            if ( wp_verify_nonce( isset($_POST['_wpnonce']), "update-tag_{$term_id}" ) ) {
                $color_code = $_POST['tcolorpic'];
                update_term_meta( $term_id, 'txm_extra_info', $color_code );
            }
        }

        function save_color_info_category( $term_id ) {
            if ( wp_verify_nonce( $_POST['_wpnonce_add-tag'], 'add-tag' ) ) {
                $color_code = $_POST['tcolorpic'];
                update_term_meta( $term_id, 'txm_extra_info', $color_code );
            }
        }

        function course_topic_edit_form_field( $term ) {
            $color_code = get_term_meta( $term->term_id, 'txm_extra_info', true );
        ?>
        <tr class="form-field form-required term-name-wrap">
			<th scope="row"><label for="tcolorpic"><?php echo __('Color', 'welearn-plugin');?></label></th>
			<td><input name="tcolorpic" id="tcolorpic" type="color" value="<?php echo esc_attr( $color_code ); ?>" >
			<p class="description"><?php echo __('Choose Taxonomy Color Here', 'welearn-plugin') ?></p></td>
		</tr>
        <?php
            }
                function course_topic_form_field() {
                ?>
            <div class="form-field term-slug-wrap">
                <label for="tcolorpic"><?php echo __('Color', 'welearn-plugin');?></label>
                <input name="tcolorpic" id="tcolorpic" type="color" value="" >
                <p><?php echo __('Choose Taxonomy Color Here', 'welearn-plugin') ?></p>
            </div>
        <?php
            }

                function course_topic_color_opt() {
                    $argumnets = [
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                        'single'            => true,
                        'description'       => 'color field for topic tax',
                        'show_in_rest'      => true,
                    ];
                    register_meta( 'term', 'txm_extra_info', $argumnets );
                }

                /**
                 * Security Check
                 *
                 * @param [type] $field
                 * @param [type] $action
                 * @param [type] $post_id
                 * @return void
                 */
                private function securityCheck( $field, $action, $post_id ) {
                    $nonce = isset( $_POST[ $field ] ) ? $_POST[ $field ] : '';

                    if ( $nonce == '' ) {
                        return false;
                    }

                    if ( ! wp_verify_nonce( $nonce, $action ) ) {
                        return false;
                    }

                    if ( ! current_user_can( 'edit_post', $post_id ) ) {
                        return false;
                    }

                    if ( wp_is_post_autosave( $post_id ) ) {
                        return false;
                    }

                    if ( wp_is_post_revision( $post_id ) ) {
                        return false;
                    }
                    return true;
                }
                /**
                 * Save Testimonial Metabox
                 *
                 * @param [type] $post_id
                 * @return void
                 */
                function weln_save_testimonial_info( $post_id ) {

                    if ( ! $this->securityCheck( 'weln_testimonial_field', 'weln_testimon', $post_id ) ) {
                        return $post_id;
                    }

                    $welntestdesig = isset( $_POST['weln_test_desig'] ) ? $_POST['weln_test_desig'] : '';

                    if ( $welntestdesig == '' ) {
                        return $post_id;
                    }

                    $welntestdesig = sanitize_text_field( $welntestdesig );

                    update_post_meta( $post_id, 'weln_testimonial_opt', $welntestdesig );
                }
                /**
                 * Save Course Metabox
                 *
                 * @param [type] $post_id
                 * @return void
                 */
                function weln_save_price( $post_id ) {

                    if ( ! $this->securityCheck( 'weln_price_field', 'weln_price', $post_id ) ) {
                        return $post_id;
                    }

                    $regulerprice = isset( $_POST['weln_rgprice'] ) ? $_POST['weln_rgprice'] : '';
                    $slrprice     = isset( $_POST['weln_rgprice'] ) ? $_POST['weln_slprice'] : '';
                    $courserating = isset( $_POST['weln_ratinge'] ) ? $_POST['weln_ratinge'] : '';

                    if ( $regulerprice == '' || $slrprice == '' ) {
                        return $post_id;
                    }

                    $regulerprice = sanitize_text_field( $regulerprice );
                    $slrprice     = sanitize_text_field( $slrprice );

                    update_post_meta( $post_id, 'weln_rgprice', $regulerprice );
                    update_post_meta( $post_id, 'weln_sleprice', $slrprice );
                    update_post_meta( $post_id, 'courserating_meta', $courserating );
                }
                /**
                 * Save Team Metabox
                 *
                 * @param [type] $post_id
                 * @return void
                 */
                function weln_save_team_info( $post_id ) {

                    if ( ! $this->securityCheck( 'weln_teame_field', 'weln_team_nn', $post_id ) ) {
                        return $post_id;
                    }

                    $tmdesignation = isset( $_POST['weln_designation'] ) ? $_POST['weln_designation'] : '';

                    $tmdefacebook = isset( $_POST['weln_fb'] ) ? $_POST['weln_fb'] : '';

                    $tmdtwitter = isset( $_POST['weln_tw'] ) ? $_POST['weln_tw'] : '';

                    $tmdlinked = isset( $_POST['weln_lkd'] ) ? $_POST['weln_lkd'] : '';
                    
                    $tminsta = isset( $_POST['weln_inst'] ) ? $_POST['weln_inst'] : '';

                    $tmyoutube = isset( $_POST['weln_yt'] ) ? $_POST['weln_yt'] : '';

                    if ( '' == $tmdesignation ) {
                        return $post_id;
                    }

                    $tmdesignation = sanitize_text_field( $tmdesignation );

                    update_post_meta( $post_id, 'weln_designation_meta', $tmdesignation );
                    update_post_meta( $post_id, 'weln_fb_meta', $tmdefacebook );
                    update_post_meta( $post_id, 'weln_tw_meta', $tmdtwitter );
                    update_post_meta( $post_id, 'weln_link_meta', $tmdlinked );
                    update_post_meta( $post_id, 'weln_insta_meta', $tminsta );
                    update_post_meta( $post_id, 'weln_yt_meta', $tmyoutube );
                }

                /**
                 * Add Custom Meta Box
                 *
                 * @return void
                 */
                function weln_courses_metabox() {
                    add_meta_box(
                        'weln_course_meta_info',
                        __( 'Course Options', 'welearn-plugin' ),
                        [ $this, 'weln_display_course_option' ],
                        'courses',
                        'normal',
                        'high',
                    );
                    add_meta_box(
                        'weln_team_meta_info',
                        __( 'Team Options', 'welearn-plugin' ),
                        [ $this, 'weln_display_team_option' ],
                        'team',
                        'normal',
                        'high',
                    );
                    add_meta_box(
                        'weln_testimonial_meta_info',
                        __( 'Testimonial Options', 'welearn-plugin' ),
                        [ $this, 'weln_display_testimonial_option' ],
                        'testimonial',
                        'normal',
                        'high',
                    );
                }
                /**
                 * Display Testimonial Authore Designation
                 *
                 * @param [type] $post
                 * @return void
                 */
                function weln_display_testimonial_option( $post ) {
                    $testimoni_info       = get_post_meta( $post->ID, 'weln_testimonial_opt', true );
                    $testi_desc_label    = __( "Designation", 'welearn-plugin' );
                    wp_nonce_field( 'weln_testimon', 'weln_testimonial_field' );
                    $courseMetabox_markup = <<<EOD
                    <div class="welen-fields">
                        <p>
                        <label class="welen_label" for="weln_test_desig">{$testi_desc_label}</label>
                        <input class="welen_field widefat" type="text" name="weln_test_desig" id="weln_test_desig" value="{$testimoni_info}">
                        </p>
                    </div>
EOD;
                    echo $courseMetabox_markup;
                }
                /**
                 * Display Meta Input Field
                 *
                 * @param [type] $post
                 * @return void
                 */
                function weln_display_course_option( $post ) {
                    $regprice       = get_post_meta( $post->ID, 'weln_rgprice', true );
                    $slprice        = get_post_meta( $post->ID, 'weln_sleprice', true );
                    $wecourserating = get_post_meta( $post->ID, 'courserating_meta', true );
                    $price_label    = __( "Reguler Price", 'welearn-plugin' );
                    $sale_label     = __( "Sale Price", 'welearn-plugin' );
                    $rating_label   = __( "Slect Course Rating", 'welearn-plugin' );
                    wp_nonce_field( 'weln_price', 'weln_price_field' );
                    $ratings        = [ "one", "two", "three", "four", "five" ];
                    $rating_options = "<option value='0'>" . __( 'Select Rating', 'welearn-plugin' ) . "</option>";
                    foreach ( $ratings as $rat ) {
                        $selected = '';
                        if ( $rat == $wecourserating ) {
                            $selected = 'selected';
                        }
                        $rating_options .= sprintf( "<option %s value='%s'>%s</option>", $selected, $rat, ucwords( $rat ) );
                    }
                    $courseMetabox_markup = <<<EOD
          <div class="welen-fields">
            <p>
            <label class="welen_label" for="weln_rgprice">{$price_label}</label>
            <input class="welen_field widefat" type="text" name="weln_rgprice" id="weln_rgprice" value="{$regprice}">
            </p>
            <p>
            <label class="welen_label" for="weln_slprice">{$sale_label}</label>
            <input class="welen_field widefat" type="text" name="weln_slprice" id="weln_slprice" value="{$slprice}">
            </p>
            <p>
            <label class="welen_label" for="weln_ratinge">{$rating_label}</label>
            <select class="welen_field widefat" name="weln_ratinge" id="weln_ratinge">
                {$rating_options}
            </select>
            </p>
          </div>
EOD;
                    echo $courseMetabox_markup;
                }
                /**
                 * Display Team
                 *
                 * @param [type] $post
                 * @return void
                 */
                function weln_display_team_option( $post ) {
                    $designation       = get_post_meta( $post->ID, 'weln_designation_meta', true );
                    $facebook       = get_post_meta( $post->ID, 'weln_fb_meta', true );
                    $twitter       = get_post_meta( $post->ID, 'weln_tw_meta', true );
                    $linkedin       = get_post_meta( $post->ID, 'weln_link_meta', true );
                    $instagram       = get_post_meta( $post->ID, 'weln_insta_meta', true );
                    $youtube       = get_post_meta( $post->ID, 'weln_yt_meta', true );


                    $designation_label = __( "Designation", 'welearn-plugin' );
                    $designation_fb    = __( "Facebook", 'welearn-plugin' );
                    $designation_tw    = __( "Twitter", 'welearn-plugin' );
                    $designation_lkd   = __( "Linkedin", 'welearn-plugin' );
                    $designation_inst  = __( "Instagram", 'welearn-plugin' );
                    $designation_yt    = __( "YouTube", 'welearn-plugin' );
                    wp_nonce_field( 'weln_team_nn', 'weln_teame_field' );

                    $courseMetabox_markup = <<<EOD
          <div class="welen-fields">
            <p>
            <label class="welen_label" for="weln_designation">{$designation_label}</label>
            <input class="welen_field widefat" type="text" name="weln_designation" id="weln_designation" value="{$designation}">
            </p>
            <p>

            <p>
            <label class="welen_label" for="weln_fb">{$designation_fb}</label>
            <input class="welen_field widefat" type="text" name="weln_fb" id="weln_fb" value="{$facebook}">
            </p>

            <p>
            <label class="welen_label" for="weln_tw">{$designation_tw}</label>
            <input class="welen_field widefat" type="text" name="weln_tw" id="weln_tw" value="{$twitter}">
            </p>

            <p>
            <label class="welen_label" for="weln_lkd">{$designation_lkd}</label>
            <input class="welen_field widefat" type="text" name="weln_lkd" id="weln_lkd" value="{$linkedin}">
            </p>

            <p>
            <label class="welen_label" for="weln_inst">{$designation_inst}</label>
            <input class="welen_field widefat" type="text" name="weln_inst" id="weln_inst" value="{$instagram}">
            </p>

            <p>
            <label class="welen_label" for="weln_yt">{$designation_yt}</label>
            <input class="welen_field widefat" type="text" name="weln_yt" id="weln_yt" value="{$youtube}">
            </p>
            <p>
          </div>
EOD;
                    echo $courseMetabox_markup;
                }

                /**
                 * Course Custom Post
                 *
                 * @return void
                 */
                function weln_courses_cpt() {
                    $labels = array(
                        'name'                  => esc_html_x( 'Courses', 'Post Type General Name', 'welearn-plugin' ),
                        'singular_name'         => esc_html_x( 'Course', 'Post Type Singular Name', 'welearn-plugin' ),
                        'menu_name'             => esc_html__( 'Courses', 'welearn-plugin' ),
                        'name_admin_bar'        => esc_html__( 'Courses', 'welearn-plugin' ),
                        'archives'              => esc_html__( 'Item Archives', 'welearn-plugin' ),
                        'attributes'            => esc_html__( 'Item Attributes', 'welearn-plugin' ),
                        'parent_item_colon'     => esc_html__( 'Parent Item:', 'welearn-plugin' ),
                        'all_items'             => esc_html__( 'All Items', 'welearn-plugin' ),
                        'add_new_item'          => esc_html__( 'Add New Course', 'welearn-plugin' ),
                        'add_new'               => esc_html__( 'Add New Courses', 'welearn-plugin' ),
                        'new_item'              => esc_html__( 'New Courses', 'welearn-plugin' ),
                        'edit_item'             => esc_html__( 'Edit Courses', 'welearn-plugin' ),
                        'update_item'           => esc_html__( 'Update Courses', 'welearn-plugin' ),
                        'view_item'             => esc_html__( 'View Courses', 'welearn-plugin' ),
                        'view_items'            => esc_html__( 'View Courses', 'welearn-plugin' ),
                        'search_items'          => esc_html__( 'Search Courses', 'welearn-plugin' ),
                        'not_found'             => esc_html__( 'Not found', 'welearn-plugin' ),
                        'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'welearn-plugin' ),
                        'featured_image'        => esc_html__( 'Courses Image', 'welearn-plugin' ),
                        'set_featured_image'    => esc_html__( 'Upload Courses image', 'welearn-plugin' ),
                        'remove_featured_image' => esc_html__( 'Remove Courses image', 'welearn-plugin' ),
                        'use_featured_image'    => esc_html__( 'Use as Courses image', 'welearn-plugin' ),
                        'insert_into_item'      => esc_html__( 'Insert into item', 'welearn-plugin' ),
                        'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'welearn-plugin' ),
                        'items_list'            => esc_html__( 'Items list', 'welearn-plugin' ),
                        'items_list_navigation' => esc_html__( 'Items list navigation', 'welearn-plugin' ),
                        'filter_items_list'     => esc_html__( 'Filter items list', 'welearn-plugin' ),
                    );
                    $args = array(
                        'label'               => esc_html__( 'Courses', 'welearn-plugin' ),
                        'description'         => esc_html__( 'Post Type Description', 'welearn-plugin' ),
                        'labels'              => $labels,
                        'supports'            => array( 'title', 'thumbnail' ),
                        'hierarchical'        => false,
                        'public'              => true,
                        'show_ui'             => true,
                        'show_in_menu'        => true,
                        'menu_position'       => 5,
                        'menu_icon'           => 'dashicons-welcome-learn-more',
                        'show_in_admin_bar'   => true,
                        'show_in_nav_menus'   => true,
                        'can_export'          => true,
                        'has_archive'         => true,
                        'exclude_from_search' => false,
                        'publicly_queryable'  => true,
                        'capability_type'     => 'page',
                    );
                    register_post_type( 'courses', $args );
                }

                /**
                 * Team Custom Post
                 *
                 * @return void
                 */
                function weln_team_cpt() {
                    $labels = array(
                        'name'                  => esc_html_x( 'Teams', 'Post Type General Name', 'welearn-plugin' ),
                        'singular_name'         => esc_html_x( 'Team', 'Post Type Singular Name', 'welearn-plugin' ),
                        'menu_name'             => esc_html__( 'Teams', 'welearn-plugin' ),
                        'name_admin_bar'        => esc_html__( 'Teams', 'welearn-plugin' ),
                        'archives'              => esc_html__( 'Item Archives', 'welearn-plugin' ),
                        'attributes'            => esc_html__( 'Item Attributes', 'welearn-plugin' ),
                        'parent_item_colon'     => esc_html__( 'Parent Item:', 'welearn-plugin' ),
                        'all_items'             => esc_html__( 'All Items', 'welearn-plugin' ),
                        'add_new_item'          => esc_html__( 'Add New Team', 'welearn-plugin' ),
                        'add_new'               => esc_html__( 'Add New Team', 'welearn-plugin' ),
                        'new_item'              => esc_html__( 'New Team', 'welearn-plugin' ),
                        'edit_item'             => esc_html__( 'Edit Team', 'welearn-plugin' ),
                        'update_item'           => esc_html__( 'Update Team', 'welearn-plugin' ),
                        'view_item'             => esc_html__( 'View Team', 'welearn-plugin' ),
                        'view_items'            => esc_html__( 'View Team', 'welearn-plugin' ),
                        'search_items'          => esc_html__( 'Search Team', 'welearn-plugin' ),
                        'not_found'             => esc_html__( 'Not found', 'welearn-plugin' ),
                        'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'welearn-plugin' ),
                        'featured_image'        => esc_html__( 'Courses Image', 'welearn-plugin' ),
                        'set_featured_image'    => esc_html__( 'Upload Team image', 'welearn-plugin' ),
                        'remove_featured_image' => esc_html__( 'Remove Team image', 'welearn-plugin' ),
                        'use_featured_image'    => esc_html__( 'Use as Team image', 'welearn-plugin' ),
                        'insert_into_item'      => esc_html__( 'Insert into item', 'welearn-plugin' ),
                        'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'welearn-plugin' ),
                        'items_list'            => esc_html__( 'Items list', 'welearn-plugin' ),
                        'items_list_navigation' => esc_html__( 'Items list navigation', 'welearn-plugin' ),
                        'filter_items_list'     => esc_html__( 'Filter items list', 'welearn-plugin' ),
                    );
                    $args = array(
                        'label'               => esc_html__( 'Team', 'welearn-plugin' ),
                        'description'         => esc_html__( 'Post Type Description', 'welearn-plugin' ),
                        'labels'              => $labels,
                        'supports'            => array( 'title', 'thumbnail' ),
                        'hierarchical'        => false,
                        'public'              => true,
                        'show_ui'             => true,
                        'show_in_menu'        => true,
                        'menu_position'       => 5,
                        'menu_icon'           => 'dashicons-businessman',
                        'show_in_admin_bar'   => true,
                        'show_in_nav_menus'   => true,
                        'can_export'          => true,
                        'has_archive'         => true,
                        'exclude_from_search' => false,
                        'publicly_queryable'  => true,
                        'capability_type'     => 'page',
                    );
                    register_post_type( 'team', $args );
                }

                /**
                 * Team Custom Post
                 *
                 * @return void
                 */
                function weln_testimonial_cpt() {
                    $labels = array(
                        'name'                  => esc_html_x( 'Testimonials', 'Post Type General Name', 'welearn-plugin' ),
                        'singular_name'         => esc_html_x( 'Testimonial', 'Post Type Singular Name', 'welearn-plugin' ),
                        'menu_name'             => esc_html__( 'Testimonials', 'welearn-plugin' ),
                        'name_admin_bar'        => esc_html__( 'Testimonials', 'welearn-plugin' ),
                        'archives'              => esc_html__( 'Item Archives', 'welearn-plugin' ),
                        'attributes'            => esc_html__( 'Item Attributes', 'welearn-plugin' ),
                        'parent_item_colon'     => esc_html__( 'Parent Item:', 'welearn-plugin' ),
                        'all_items'             => esc_html__( 'All Items', 'welearn-plugin' ),
                        'add_new_item'          => esc_html__( 'Add New Testimonial', 'welearn-plugin' ),
                        'add_new'               => esc_html__( 'Add New Testimonial', 'welearn-plugin' ),
                        'new_item'              => esc_html__( 'New Testimonial', 'welearn-plugin' ),
                        'edit_item'             => esc_html__( 'Edit Testimonial', 'welearn-plugin' ),
                        'update_item'           => esc_html__( 'Update Testimonial', 'welearn-plugin' ),
                        'view_item'             => esc_html__( 'View Testimonial', 'welearn-plugin' ),
                        'view_items'            => esc_html__( 'View Testimonial', 'welearn-plugin' ),
                        'search_items'          => esc_html__( 'Search Testimonial', 'welearn-plugin' ),
                        'not_found'             => esc_html__( 'Not found', 'welearn-plugin' ),
                        'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'welearn-plugin' ),
                        'featured_image'        => esc_html__( 'Courses Image', 'welearn-plugin' ),
                        'set_featured_image'    => esc_html__( 'Testimonials Authore image', 'welearn-plugin' ),
                        'remove_featured_image' => esc_html__( 'Remove Authore Testimonials image', 'welearn-plugin' ),
                        'use_featured_image'    => esc_html__( 'Use as Testimonials image', 'welearn-plugin' ),
                        'insert_into_item'      => esc_html__( 'Insert into item', 'welearn-plugin' ),
                        'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'welearn-plugin' ),
                        'items_list'            => esc_html__( 'Items list', 'welearn-plugin' ),
                        'items_list_navigation' => esc_html__( 'Items list navigation', 'welearn-plugin' ),
                        'filter_items_list'     => esc_html__( 'Filter items list', 'welearn-plugin' ),
                    );
                    $args = array(
                        'label'               => esc_html__( 'Testimonial', 'welearn-plugin' ),
                        'description'         => esc_html__( 'Post Type Description', 'welearn-plugin' ),
                        'labels'              => $labels,
                        'supports'            => array( 'title', 'editor', 'thumbnail' ),
                        'hierarchical'        => false,
                        'public'              => true,
                        'show_ui'             => true,
                        'show_in_menu'        => true,
                        'menu_position'       => 5,
                        'menu_icon'           => 'dashicons-businessman',
                        'show_in_admin_bar'   => true,
                        'show_in_nav_menus'   => true,
                        'can_export'          => true,
                        'has_archive'         => true,
                        'exclude_from_search' => false,
                        'publicly_queryable'  => true,
                        'capability_type'     => 'page',
                    );
                    register_post_type( 'testimonial', $args );
                }

                /**
                 * Course Custom Post
                 *
                 * @return void
                 */
                function weln_courses_topic_taxonomy() {
                    register_taxonomy(
                        'course_topic',
                        'courses',
                        array(
                            'hierarchical'      => true,
                            'label'             => __( 'Courses Topic', 'welearn-plugin' ),
                            'show_ui'           => true,
                            'query_var'         => true,
                            'show_admin_column' => true,
                            'pages'             => true,
                            'show_admin_column' => true,
                            'rewrite'           => array(
                                'slug'       => 'product-category',
                                'with_front' => true,
                            ),

                        )
                    );
                }

                /**
                 * Load Plugin Textdomain
                 *
                 * @return void
                 */
                function weln_load_textdomain() {
                    load_plugin_textdomain( 'welearn-plugin', false, WELEARNDIR . "/languages" );
                }

        }
        new WelearnPlugin();